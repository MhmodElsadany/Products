package com.example.products.UI;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.products.Adapter.CustomAdapter;
import com.example.products.ProductModel;
import com.example.products.ViewModel.ProductsViewModel;
import com.example.products.R;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class Products extends AppCompatActivity {
    @BindView(R.id.recycler_view)
    RecyclerView recyclerView;
    ProductsViewModel model;
    CustomAdapter mCustomAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.poducts);
        ButterKnife.bind(this);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        model = ViewModelProviders.of(this).get(ProductsViewModel.class);
        model.getResult(Products.this).observe(this, new Observer<ArrayList<ProductModel>>() {
            @Override
            public void onChanged(@Nullable ArrayList<ProductModel> s) {
                mCustomAdapter = new CustomAdapter(Products.this, s);
                recyclerView.setAdapter(mCustomAdapter);
            }


        });


    }

}
