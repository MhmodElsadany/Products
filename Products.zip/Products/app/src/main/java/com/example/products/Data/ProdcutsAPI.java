package com.example.products.Data;

import com.example.products.ProductModel;

import java.util.ArrayList;

import io.reactivex.Observable;
import retrofit2.http.POST;

public interface ProdcutsAPI {
    String BASE_URL = "http://192.168.1.12:8080/product_mangment/";

    @POST("selectcar.php")
    Observable<ArrayList<ProductModel>> getHeroes();
}
