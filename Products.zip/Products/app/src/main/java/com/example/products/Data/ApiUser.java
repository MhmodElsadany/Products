package com.example.products.Data;

import com.example.products.Clients;

import java.lang.reflect.Array;
import java.util.ArrayList;

import io.reactivex.Observable;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiUser {
    String BASE_URL = "http://192.168.1.12:8080/product_mangment/";

    @FormUrlEncoded
    @POST("userName.php")
    Observable<ArrayList<Clients>> getHeroes(@Field("id_user") String id_user);
}

