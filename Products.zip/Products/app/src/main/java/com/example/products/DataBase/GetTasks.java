package com.example.products.DataBase;

import android.content.Context;
import android.os.AsyncTask;

import java.util.ArrayList;
import java.util.List;

class GetTasks extends AsyncTask<Void, Void, List<Task>> {
    Context mContext;
    List<Task> mTasks = new ArrayList<>();

    public GetTasks(Context mContext) {
        this.mContext = mContext;

    }


    @Override
    protected List<Task> doInBackground(Void... voids) {
        List<Task> taskList = DatabaseClient
                .getInstance(mContext.getApplicationContext())
                .getAppDatabase()
                .taskDao()
                .getAll();
        mTasks = taskList;
        return taskList;
    }

    @Override
    protected void onPostExecute(List<Task> tasks) {
        super.onPostExecute(tasks);
        mTasks = (tasks);
    }

    public List<Task> getPoducts(Context mContext) {
        GetTasks gt = new GetTasks(mContext);
        gt.execute();
        return doInBackground();
    }

}